#Variational Autoencoder Code
from keras.models import Model
from keras.layers import Layer
from keras.layers import Input
from keras.layers import Conv2D, MaxPooling2D, UpSampling2D
from keras.layers import Dropout
from keras.layers import concatenate
from keras.layers import Flatten
from keras.layers import Dense
from keras.layers import Reshape
from keras.backend import random_normal
import tensorflow
from tensorflow import exp
from tensorflow import shape

class Sampling(Layer):
        def call(self, inputs):
            z_mean, z_log_var = inputs
            batch = shape(z_mean)[0]
            dim = shape(z_mean)[1]
            epsilon = random_normal(shape=(batch, dim))
            return z_mean + exp(0.5 * z_log_var) * epsilon

def build():

    #Start of Encoder
    latent_dim = 2
    input_ = Input(shape=(40, 40, 2), name='input_tensor')
    # Level 1
    conv1_1 = Conv2D(16, (3, 3), padding='same', activation='relu')(input_) 
    conv1_2 = Conv2D(16, (3, 3), padding='same', activation='relu')(conv1_1)
    #### Level 2
    pool2_1 = MaxPooling2D((2, 2), padding='same')(conv1_2) 
    conv2_1 = Conv2D(32, (3, 3), padding='same', activation='relu')(pool2_1)
    drop2_1 = Dropout(0.1)(conv2_1)
    conv2_2 = Conv2D(32, (3, 3), padding='same', activation='relu')(drop2_1)
    ######### Level 3
    pool3_1 = MaxPooling2D((2, 2), padding='same')(conv2_2) 
    conv3_1 = Conv2D(64, (3, 3), padding='same', activation='relu')(pool3_1)
    conv3_2 = Conv2D(64, (3, 3), padding='same', activation='relu')(conv3_1)
    ################ End of Encoder

    ################ Start of Variational Auto-Encoder
    Flat1 = Flatten()(conv3_2)
    Dense1 = Dense(16, activation="relu")(Flat1)
    z_mean = Dense(latent_dim, name="z_mean")(Dense1)
    z_log_var = Dense(latent_dim, name="z_log_var")(Dense1)
    z = Sampling()([z_mean, z_log_var])
    Dense2 = Dense(10 * 10 * 64, activation="relu")(z)
    Reshape1 = Reshape((10, 10, 64))(Dense2)
    ################ End of Variational Auto-Encoder

    ################ Start of Decoder
    ######### Level 3 Continued
    conv3_3 = Conv2D(64, (3, 3), padding='same', activation='relu')(Reshape1)
    conv3_4 = Conv2D(64, (3, 3), padding='same', activation='relu')(conv3_3)
    up3_1 = UpSampling2D()(conv3_4)
    #### Level 2
    concat2 = concatenate([conv2_2, up3_1], axis=3)
    conv2_3 = Conv2D(32, (3, 3), padding='same', activation='relu')(concat2)
    drop2_2 = Dropout(0.1)(conv2_3)
    conv2_4 = Conv2D(32, (3, 3), padding='same', activation='relu')(drop2_2)
    up2_1 = UpSampling2D()(conv2_4)
    # Level 1
    concat1 = concatenate([conv1_2, up2_1], axis=3)
    conv1_3 = Conv2D(16, (3, 3), padding='same', activation='relu')(concat1)
    conv1_4 = Conv2D(16, (3, 3), padding='same', activation='relu')(conv1_3)
    output = Conv2D(1, (3, 3), padding='same', activation='sigmoid')(conv1_4)
    # End of Decoder

    model = Model(input_, output)
    return model